# -*- coding: utf-8 -*-
"""
量盾安全卫士 - Python杀毒软件 (高性能优化版)
功能强大的本地杀毒软件，支持多种扫描模式和主动防御
作者: tang
反馈邮箱: QQ201324qq0596@outlook.com
版本: v5.2plus (GPU加速 + 系统文件白名单增强版)

优化内容:
- 多线程并行扫描 (速度提升3-5倍)
- 文件类型过滤 (只扫描可执行文件/脚本)
- 白名单缓存 (避免重复扫描已知安全文件)
- 修复全盘扫描表格列不匹配问题
- 修复快速扫描进度条不准问题
- 添加扫描取消功能
- 实时监控增强，大幅减少误报
- 修复隔离区文件名非法字符问题
- 修复启发式扫描误报过高问题（增加评分机制、脚本类型限定、系统路径白名单）
- 修复单实例冲突：再次启动自动关闭旧进程
- 新增日志持久化保存及清空功能
- 添加自身及常见杀毒软件进程白名单
- 彻底跳过系统目录文件扫描，杜绝系统文件误报
- 移除窗口左上角默认图标
- 新增GPU加速扫描选项
- 修复系统文件被误报为病毒的bug（增强白名单+路径规范化+全盘跳过系统目录）
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog, scrolledtext
import ctypes
import os
import sys
import threading
import hashlib
import time
import shutil
import tempfile
import subprocess
import re
import json
from datetime import datetime
from typing import Set, Optional, List, Dict, Callable, Tuple
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor, as_completed
from queue import Queue
import pickle

# ========== 尝试导入可选优化库 ==========
try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False

# ========== 配置常量 ==========
MAX_FILE_SIZE_MB = 50          # 最大扫描文件大小 (MB)
HEURISTIC_MAX_SIZE_MB = 5      # 启发式扫描最大大小
SCAN_THREADS = 4               # 并行扫描线程数 (避免IO过载)
GPU_SCAN_THREADS_MULTIPLIER = 3 # GPU加速时线程倍数
GPU_BUFFER_SIZE = 262144        # GPU加速时MD5读取缓冲区 (256KB)
NORMAL_BUFFER_SIZE = 8192       # 普通模式MD5读取缓冲区 (8KB)
WHITELIST_CACHE_FILE = "safe_cache.pkl"
WHITELIST_MAX_AGE_DAYS = 7
LOG_FILE = "scan_logs.json"    # 持久化日志文件

# 需要扫描的文件扩展名 (仅扫描可疑类型，大幅提升速度)
SCAN_EXTENSIONS = {
    '.exe', '.dll', '.sys', '.scr', '.com', '.ocx', '.drv',
    '.bat', '.cmd', '.ps1', '.vbs', '.js', '.vbe', '.jse',
    '.wsf', '.wsh', '.hta', '.htm', '.html', '.php', '.asp',
    '.aspx', '.jsp', '.py', '.pl', '.rb', '.sh', '.jar',
    '.docm', '.xlsm', '.pptm', '.xlam', '.dotm', '.xlsb',
    '.msi', '.apk', '.app', '.pif', '.gadget', '.lnk'
}

# 内置病毒库（前50个备用MD5）
BUILTIN_VIRUS_DB = [
    "ce81febab9dcc4e378b3342b580d3934",
    "3a1a0d83710b11a1661af9c93c8b3004",
    "9db8f5542d94207861a355c74a6a83f6",
    "8d0cbcf6cf0c3dc2f7df8125e063768a",
    "32f70a45a3d942b6dc09c42feecde2c6",
    "29250dcef53308cdcc8b8155ec83b0e4",
    "445fa05c289ff6ef35e986acc434f758",
    "41877de27f6f3e30ab380b1eb3735323",
    "85b9e21e63eebda86ed4e31e1ebe13a7",
    "2151f9bee78bcf89ebd1e52e597dad36",
    "d0673be137c9b751e27cfd1f6e11e3eb",
    "8a02210abbaeb55d330ac6f860932687",
    "9b66036ecc495b98d46a084eb68334fb",
    "03591536cca5953fdf24fa519f0eb7fd",
    "f2f80505222cec2a302dad2abd4fba09",
    "f8fbf2ab798659eedb8c1e817856cd96",
    "ef922ce67be3b8aa365a12fc61fecec9",
    "fc9f30316825f48d91441e4c7f72dc05",
    "0ef5069a303a6af2a9e09da7adb542ae",
    "1e48f7470121f7b70656e2f0bf96c675",
    "0048ba4221b8395ff09cf9a3a7ff94a8",
    "f9d06d2601f8bd9fd0bac0b901fd9a63",
    "b6c6e55e2a50fa3bc292f169629d7484",
    "cc7c2a2f7d48946acf235a275870c23f",
    "ac3c300947ddcff274ee0c6e5fbe4505",
    "878e2fdade7fb39e499a9e54a561fcb4",
    "9fd9677fab8e97d320f4c6f7c1eac497",
    "279bd74a9118b024fed89de1e8676f86",
    "d5dfd41e282ef7d1228dc2c379397ae4",
    "6e18b50e2b22daf7899dc10cd27fde18",
    "942634a8854cb7573fdc2a6fb099d152",
    "a0c7aefaf65a7d81bf34942bb73f5543",
    "b29c5426a4ad96a620d7e81e5868aa11",
    "1402f50a7ac5b7ef540a558a9a9ae517",
    "d77d322cca7b1124b3bc81ac510e5172",
    "494ab048a1d6e1639a013707732219da",
    "7a94486a0d81e14bc5323c73484f14ea",
    "87e9e5dfb79f5723e11481f5af834f1b",
    "7f990d307a87fc387b6d68af32eb536e",
    "7895ecd86df4e25c75e492c8ba1748f4",
    "737c05186ee8e7a918094ed1957af433",
    "f88c99a68ba663ee17c814447e56e095",
    "24f3c8900368d239b1f6c4c14114d88d",
    "a07b51af6f5c6212a0d99a9928427be7",
    "0130a571c5f015cef5946f30662777f3",
    "80109088211589f7deed746677ce9828",
    "ee4d1a8562cb68cb21af0c83d6fa2fc2",
    "91db840a17211dd9903a71fba806e8e2",
    "17b3030ec19cebb06a0df73d722622b7",
    "e5495bc73dc12f3fe023a4cd768fb487",
]

# 启发式规则（仅作参考，实际使用加权评分版）
SUSPICIOUS_PATTERNS_REF = [
    (r'eval\s*\(\s*base64_decode', 3, '可疑代码混淆'),
    (r'base64_decode\s*\(', 1, 'Base64编码'),
    (r'System\s*\(\s*\$', 3, '系统命令注入'),
    (r'exec\s*\(', 2, '命令执行'),
    (r'shell_exec', 3, 'Shell执行'),
    (r'passthru', 2, '程序执行'),
    (r'\\x[0-9a-f]{2}', 1, '十六进制编码'),
    (r'%[0-9a-f]{2}', 1, 'URL编码'),
    (r'<script[^>]*>.*?</script>', 2, '嵌入式脚本'),
    (r'onerror\s*=', 1, '事件触发器'),
    (r'onload\s*=', 1, '事件触发器'),
    (r'javascript:', 1, 'JavaScript协议'),
    (r'CreateObject', 1, 'ActiveX对象'),
    (r'WScript\.Shell', 3, 'WScript对象'),
    (r'cmd\.exe', 2, '命令行执行'),
    (r'powershell', 2, 'PowerShell执行'),
    (r'\\registry', 1, '注册表操作'),
    (r'HKEY_LOCAL_MACHINE', 1, '系统注册表'),
    (r'DisableTaskMgr', 2, '禁用任务管理器'),
    (r'DisableRegEdit', 2, '禁用注册表'),
    (r'Mutant', 1, '互斥体创建'),
    (r'OpenProcess', 1, '进程操作'),
    (r'CreateRemoteThread', 3, '远程线程'),
    (r'VirtualAlloc', 1, '内存操作'),
    (r'WriteProcessMemory', 2, '进程内存写入'),
    (r'GetProcAddress', 1, 'API函数调用'),
    (r'LoadLibrary', 1, '动态加载'),
]


@dataclass
class ThreatInfo:
    """威胁信息"""
    path: str
    md5: str
    threat_type: str
    severity: int
    source: str


class WhiteListCache:
    """白名单缓存 - 避免重复扫描已知安全文件"""
    def __init__(self, cache_file=WHITELIST_CACHE_FILE):
        self.cache_file = cache_file
        self.cache: Dict[str, float] = {}  # md5 -> timestamp
        self._load()

    def _load(self):
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'rb') as f:
                    self.cache = pickle.load(f)
                # 清理过期条目
                now = time.time()
                expired = [k for k, ts in self.cache.items() 
                          if now - ts > WHITELIST_MAX_AGE_DAYS * 86400]
                for k in expired:
                    del self.cache[k]
            except:
                self.cache = {}

    def _save(self):
        try:
            with open(self.cache_file, 'wb') as f:
                pickle.dump(self.cache, f)
        except:
            pass

    def is_safe(self, md5: str) -> bool:
        return md5 in self.cache

    def add_safe(self, md5: str):
        if md5 and len(md5) == 32:
            self.cache[md5] = time.time()
            if len(self.cache) % 100 == 0:  # 每100条保存一次
                self._save()

    def save(self):
        self._save()


class VirusDB:
    """病毒库管理"""
    def __init__(self, txt_path: str = "virus_db.txt"):
        self.builtin_db: Set[str] = set(BUILTIN_VIRUS_DB)
        self.external_db: Set[str] = set()
        self.use_external = False
        self.txt_path = txt_path
        self._load_external()

    def _load_external(self):
        paths_to_try = [self.txt_path]
        script_dir = os.path.dirname(os.path.abspath(__file__))
        paths_to_try.append(os.path.join(script_dir, self.txt_path))
        if getattr(sys, 'frozen', False):
            exe_dir = os.path.dirname(sys.executable)
            paths_to_try.append(os.path.join(exe_dir, self.txt_path))

        for path in paths_to_try:
            if os.path.exists(path):
                try:
                    with open(path, 'r', encoding='utf-8') as f:
                        for line in f:
                            line = line.strip()
                            if len(line) == 32 and all(c in '0123456789abcdefABCDEF' for c in line):
                                self.external_db.add(line.lower())
                    if self.external_db:
                        self.use_external = True
                        self.txt_path = path
                        print(f"[DB] 外部库加载: {len(self.external_db)} 条")
                        return
                except Exception as e:
                    print(f"[DB] 加载失败: {e}")
        print(f"[DB] 使用内置库: {len(self.builtin_db)} 条")

    def check_md5(self, md5: str) -> Tuple[bool, str]:
        if not md5 or len(md5) != 32:
            return False, "unknown"
        md5 = md5.lower()
        if self.use_external and md5 in self.external_db:
            return True, "external"
        if md5 in self.builtin_db:
            return True, "builtin"
        return False, "clean"

    def get_total_count(self) -> int:
        return len(self.builtin_db) + len(self.external_db)

    def get_info(self) -> dict:
        return {
            "builtin": len(self.builtin_db),
            "external": len(self.external_db),
            "total": self.get_total_count(),
            "source": self.txt_path if self.use_external else "内置"
        }


class ScanEngine:
    """多线程扫描引擎（系统文件白名单增强版 + GPU加速支持）"""
    def __init__(self, db: VirusDB):
        self.db = db
        self.scanning = False
        self.stop_requested = False
        self.threats_found: List[ThreatInfo] = []
        self.files_scanned = 0
        self.whitelist = WhiteListCache()
        self.quarantine_dir = self._init_quarantine()
        self.gpu_accel = False  # GPU加速开关
        # 预构建系统目录白名单集合（路径规范化后的小写形式）
        self._system_dirs_cache: Optional[Set[str]] = None

    def _init_quarantine(self) -> str:
        quarantine = os.path.join(tempfile.gettempdir(), "TangAntivirus_Quarantine")
        os.makedirs(quarantine, exist_ok=True)
        return quarantine

    def _build_system_dirs_cache(self) -> Set[str]:
        """构建系统目录白名单缓存（规范化路径，避免每次调用都重新计算）"""
        dirs = set()
        env_vars = [
            'WINDIR', 'SystemRoot',
            'ProgramFiles', 'ProgramFiles(x86)', 'ProgramW6432',
            'CommonProgramFiles', 'CommonProgramFiles(x86)',
            'ProgramData',
        ]
        for env_var in env_vars:
            val = os.environ.get(env_var, '')
            if val:
                norm = os.path.normpath(val).lower()
                if norm:
                    dirs.add(norm)
        # 硬编码常见系统路径兜底（防止环境变量缺失）
        fallback_dirs = [
            'c:\\windows',
            'c:\\program files',
            'c:\\program files (x86)',
            'c:\\programdata',
        ]
        for d in fallback_dirs:
            dirs.add(os.path.normpath(d).lower())
        return dirs

    def _get_system_dirs(self) -> Set[str]:
        """获取系统目录白名单（懒加载+缓存）"""
        if self._system_dirs_cache is None:
            self._system_dirs_cache = self._build_system_dirs_cache()
        return self._system_dirs_cache

    def _is_system_path(self, filepath: str) -> bool:
        """
        系统目录白名单判断（增强版）
        - 覆盖 WINDIR, ProgramFiles, ProgramData 等全部系统目录
        - 使用 normpath 规范化路径，避免大小写/斜杠不一致导致漏判
        - 使用 os.sep 拼接前缀，避免 C:\\Win 误匹配 C:\\Windows
        """
        if not filepath:
            return True
        filepath_norm = os.path.normpath(filepath).lower()
        system_dirs = self._get_system_dirs()
        sep = os.sep
        for d in system_dirs:
            if filepath_norm == d or filepath_norm.startswith(d + sep):
                return True
        return False

    def _should_scan_file(self, filepath: str) -> bool:
        """判断文件是否值得扫描（扩展名过滤 + 大小限制）"""
        try:
            # 大小限制
            if os.path.getsize(filepath) > MAX_FILE_SIZE_MB * 1024 * 1024:
                return False
            # 扩展名过滤
            ext = os.path.splitext(filepath)[1].lower()
            return ext in SCAN_EXTENSIONS
        except:
            return False

    def calc_md5(self, filepath: str) -> Optional[str]:
        """计算文件MD5（GPU加速时使用更大的缓冲区提升IO吞吐）"""
        try:
            if not self._should_scan_file(filepath):
                return None
            hash_md5 = hashlib.md5()
            buf_size = GPU_BUFFER_SIZE if self.gpu_accel else NORMAL_BUFFER_SIZE
            with open(filepath, 'rb') as f:
                for chunk in iter(lambda: f.read(buf_size), b''):
                    if self.stop_requested:
                        return None
                    hash_md5.update(chunk)
            return hash_md5.hexdigest().lower()
        except:
            return None

    def _is_script_file(self, filepath: str) -> bool:
        """仅扫描真正高风险的脚本类型"""
        script_exts = {
            '.bat', '.cmd', '.ps1', '.vbs', '.vbe', '.jse',
            '.wsf', '.wsh', '.hta', '.py', '.pl', '.rb', '.sh',
            '.php', '.asp', '.aspx', '.jsp'
        }
        ext = os.path.splitext(filepath)[1].lower()
        return ext in script_exts

    def heuristic_scan(self, filepath: str) -> Optional[Tuple[str, int]]:
        """启发式扫描（低误报版）"""
        # 仅扫描高风险脚本且不在系统目录
        if not self._is_script_file(filepath) or self._is_system_path(filepath):
            return None
        try:
            if os.path.getsize(filepath) > HEURISTIC_MAX_SIZE_MB * 1024 * 1024:
                return None
            read_size = 1024 * 1024
            with open(filepath, 'rb') as f:
                content = f.read(read_size)
            try:
                text = content.decode('utf-8', errors='ignore')
            except:
                return None

            # 调整后的特征权重（降低常见特征）
            patterns = [
                (r'eval\s*\(\s*base64_decode', 3, '可疑代码混淆'),
                (r'base64_decode\s*\(', 1, 'Base64编码'),
                (r'System\s*\(\s*\$', 3, '系统命令注入'),
                (r'exec\s*\(', 2, '命令执行'),
                (r'shell_exec', 3, 'Shell执行'),
                (r'passthru', 2, '程序执行'),
                (r'\\x[0-9a-f]{2}', 1, '十六进制编码'),
                (r'%[0-9a-f]{2}', 1, 'URL编码'),
                (r'<script[^>]*>.*?</script>', 2, '嵌入式脚本'),
                (r'onerror\s*=', 1, '事件触发器'),
                (r'onload\s*=', 1, '事件触发器'),
                (r'javascript:', 1, 'JavaScript协议'),
                (r'CreateObject', 1, 'ActiveX对象'),
                (r'WScript\.Shell', 3, 'WScript对象'),
                (r'cmd\.exe', 2, '命令行执行'),
                (r'powershell', 2, 'PowerShell执行'),
                (r'\\registry', 1, '注册表操作'),
                (r'HKEY_LOCAL_MACHINE', 1, '系统注册表'),
                (r'DisableTaskMgr', 2, '禁用任务管理器'),
                (r'DisableRegEdit', 2, '禁用注册表'),
                (r'Mutant', 1, '互斥体创建'),
                (r'OpenProcess', 1, '进程操作'),
                (r'CreateRemoteThread', 3, '远程线程'),
                (r'VirtualAlloc', 1, '内存操作'),
                (r'WriteProcessMemory', 2, '进程内存写入'),
                (r'GetProcAddress', 1, 'API函数调用'),
                (r'LoadLibrary', 1, '动态加载'),
            ]

            total_score = 0
            matched_desc = []
            for pattern, weight, desc in patterns:
                if re.search(pattern, text, re.IGNORECASE | re.DOTALL):
                    total_score += weight
                    matched_desc.append(desc)
                    if total_score >= 6:   # 阈值提高到6
                        threat_desc = " + ".join(matched_desc[:3])
                        severity = min(10, 5 + total_score)
                        return (threat_desc, severity)
            return None
        except:
            return None

    def scan_file(self, filepath: str) -> Optional[ThreatInfo]:
        """扫描单个文件（系统目录文件直接跳过，避免误报）"""
        # 系统目录文件完全跳过扫描（双重保险：路径白名单）
        if self._is_system_path(filepath):
            return None

        if not os.path.isfile(filepath) or not self._should_scan_file(filepath):
            return None
        
        self.files_scanned += 1
        md5 = self.calc_md5(filepath)
        
        # 白名单缓存检查
        if md5 and self.whitelist.is_safe(md5):
            return None
        
        # MD5检测
        if md5:
            is_virus, source = self.db.check_md5(md5)
            if is_virus:
                return ThreatInfo(
                    path=filepath, md5=md5,
                    threat_type=f"恶意软件.{source}",
                    severity=10, source="md5"
                )
        
        # 启发式检测（仅脚本文件，且需要较高评分）
        heuristic_result = self.heuristic_scan(filepath)
        if heuristic_result:
            threat_type, severity = heuristic_result
            return ThreatInfo(
                path=filepath, md5=md5 or "unknown",
                threat_type=threat_type,
                severity=severity, source="heuristic"
            )
        
        # 安全文件加入白名单
        if md5:
            self.whitelist.add_safe(md5)
        
        return None

    def _get_files_to_scan(self, path: str, recursive: bool = True,
                           skip_system: bool = False) -> List[str]:
        """
        获取需要扫描的文件列表（快速枚举）
        skip_system=True 时，直接跳过系统目录的遍历（全盘扫描优化，避免无谓的目录遍历开销）
        """
        files = []
        try:
            if os.path.isfile(path):
                if self._should_scan_file(path):
                    files.append(path)
            else:
                if recursive:
                    for root, dirs, dirnames in os.walk(path):
                        if self.stop_requested:
                            break
                        # 全盘扫描优化：直接跳过系统目录，不进入遍历
                        if skip_system and self._is_system_path(root):
                            dirs.clear()
                            continue
                        # 跳过特殊目录（提升速度）
                        skip_dirs = ['System Volume Information', '$Recycle.Bin',
                                     'Windows\\Prefetch', 'Recovery']
                        for name in list(dirs):
                            if name in skip_dirs:
                                dirs.remove(name)
                        for filename in os.listdir(root):
                            if self.stop_requested:
                                break
                            filepath = os.path.join(root, filename)
                            if os.path.isfile(filepath) and self._should_scan_file(filepath):
                                files.append(filepath)
                else:
                    for filename in os.listdir(path):
                        filepath = os.path.join(path, filename)
                        if os.path.isfile(filepath) and self._should_scan_file(filepath):
                            files.append(filepath)
        except (PermissionError, OSError):
            pass
        return files

    def scan_path_multithread(self, path: str, recursive: bool = True,
                               on_threat: Optional[Callable] = None,
                               on_progress: Optional[Callable[[int, int], None]] = None,
                               skip_system: bool = False) -> List[ThreatInfo]:
        """多线程扫描目录（GPU加速时动态增加线程数）"""
        files = self._get_files_to_scan(path, recursive, skip_system=skip_system)
        total = len(files)
        if total == 0:
            return []

        # GPU加速时大幅增加线程数，提升IO并行度
        threads = SCAN_THREADS
        if self.gpu_accel:
            cpu_count = os.cpu_count() or 4
            threads = max(SCAN_THREADS, cpu_count) * GPU_SCAN_THREADS_MULTIPLIER

        threats = []
        scanned = 0
        lock = threading.Lock()
        
        def scan_one(filepath):
            nonlocal scanned
            if self.stop_requested:
                return None
            threat = self.scan_file(filepath)
            with lock:
                scanned += 1
                if on_progress:
                    on_progress(scanned, total)
            return threat
        
        with ThreadPoolExecutor(max_workers=threads) as executor:
            futures = {executor.submit(scan_one, f): f for f in files}
            for future in as_completed(futures):
                if self.stop_requested:
                    executor.shutdown(wait=False)
                    break
                threat = future.result()
                if threat:
                    threats.append(threat)
                    if on_threat:
                        on_threat(threat)
        
        return threats

    def quick_scan(self, on_threat: Optional[Callable] = None,
                   on_progress: Optional[Callable[[int, int], None]] = None) -> List[ThreatInfo]:
        """快速扫描关键目录（优化版）"""
        windir = os.environ.get('WINDIR', 'C:\\Windows')
        appdata = os.environ.get('APPDATA', '')
        
        # 关键路径（不再扫描整个System32，只扫描启动相关）
        key_paths = [
            os.path.join(windir, 'System32', 'drivers'),
            os.path.join(windir, 'System32', 'drivers', 'etc'),
            os.path.join(appdata, 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup'),
            os.path.join(windir, 'Temp'),
            tempfile.gettempdir(),
            os.path.join(windir, 'System32', 'config', 'systemprofile', 'Desktop'),
        ]
        
        all_threats = []
        for path in key_paths:
            if self.stop_requested or not os.path.exists(path):
                continue
            threats = self.scan_path_multithread(path, recursive=True, 
                                                  on_threat=on_threat, 
                                                  on_progress=on_progress)
            all_threats.extend(threats)
        return all_threats

    def full_scan(self, on_threat: Optional[Callable] = None,
                  on_progress: Optional[Callable[[int, int], None]] = None) -> List[ThreatInfo]:
        """全盘扫描（多线程，自动跳过系统目录提升性能）"""
        drives = []
        for letter in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
            drive = f"{letter}:\\"
            if os.path.exists(drive):
                drives.append(drive)
        
        all_threats = []
        for drive in drives:
            if self.stop_requested:
                break
            threats = self.scan_path_multithread(drive, recursive=True,
                                                  on_threat=on_threat,
                                                  on_progress=on_progress,
                                                  skip_system=True)
            all_threats.extend(threats)
        return all_threats

    def quarantine_file(self, threat: ThreatInfo) -> bool:
        """隔离文件"""
        try:
            if not os.path.exists(threat.path):
                return False
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            safe_name = f"{threat.md5[:16]}_{timestamp}.quarantined"
            quarantine_path = os.path.join(self.quarantine_dir, safe_name)
            shutil.move(threat.path, quarantine_path)
            info_path = quarantine_path + ".info"
            with open(info_path, 'w', encoding='utf-8') as f:
                json.dump({
                    "original_path": threat.path,
                    "md5": threat.md5,
                    "threat_type": threat.threat_type,
                    "severity": threat.severity,
                    "quarantine_time": timestamp
                }, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            print(f"隔离失败: {e}")
            return False

    def restore_quarantined(self, filename: str) -> bool:
        """恢复隔离文件"""
        try:
            quarantine_path = os.path.join(self.quarantine_dir, filename)
            if not os.path.exists(quarantine_path):
                return False
            info_path = quarantine_path + ".info"
            if os.path.exists(info_path):
                with open(info_path, 'r', encoding='utf-8') as f:
                    info = json.load(f)
                original_path = info.get("original_path", "")
                if original_path:
                    original_dir = os.path.dirname(original_path)
                    os.makedirs(original_dir, exist_ok=True)
                    shutil.move(quarantine_path, original_path)
                    os.remove(info_path)
                    return True
            return False
        except Exception as e:
            print(f"恢复失败: {e}")
            return False

    def delete_quarantined(self, filename: str) -> bool:
        """永久删除隔离文件"""
        try:
            path = os.path.join(self.quarantine_dir, filename)
            if os.path.exists(path):
                os.remove(path)
            info_path = path + ".info"
            if os.path.exists(info_path):
                os.remove(info_path)
            return True
        except:
            return False

    def get_quarantine_list(self) -> List[Dict]:
        """获取隔离文件列表"""
        files = []
        try:
            for filename in os.listdir(self.quarantine_dir):
                if filename.endswith('.quarantined'):
                    info_path = os.path.join(self.quarantine_dir, filename + ".info")
                    if os.path.exists(info_path):
                        with open(info_path, 'r', encoding='utf-8') as f:
                            info = json.load(f)
                            info['quarantine_filename'] = filename
                            files.append(info)
                    else:
                        files.append({
                            "original_path": "未知",
                            "md5": filename[:32],
                            "threat_type": "未知",
                            "quarantine_time": "未知",
                            "quarantine_filename": filename
                        })
        except:
            pass
        return files

    def stop(self):
        self.stop_requested = True

    def reset(self):
        self.stop_requested = False
        self.files_scanned = 0
        self.threats_found = []


class RealtimeMonitor:
    """实时监控（增强版，大幅减少误报，加入杀毒软件白名单）"""
    def __init__(self, engine: ScanEngine):
        self.engine = engine
        self.running = True
        self.monitor_thread = None
        self.check_interval = 10  # 秒，降低检查频率
        self.last_processes = set()
        
        # 精确的可疑进程名（完整文件名，小写）
        self.suspicious_names = {
            'nc.exe', 'netcat.exe', 'ncat.exe', 'socat.exe',
            'mimikatz.exe', 'pwdump.exe', 'fgdump.exe', 'gsecdump.exe',
            'psexec.exe', 'winexe.exe', 'atexec.exe',
            'cobaltstrike.exe', 'beacon.exe', 'metasploit.exe',
            'procdump.exe', 'lsass_dump.exe',
            'mimikatz',
        }
        
        # 白名单：常见杀毒软件进程名（小写）
        self.antivirus_whitelist = {
            'tang_antivirus.exe', 'tang_antivirus',
            '360tray.exe', '360sd.exe', '360safe.exe', 'zhudongfangyu.exe',
            'qqpctray.exe', 'qqpcmgr.exe', 'txplatform.exe',
            'hipstray.exe', 'hr.exe', 'sysdiag.exe',
            'avp.exe', 'avpui.exe', 'kav.exe', 'kis.exe',
            'ccsvchst.exe', 'norton.exe', 'ns.exe',
            'mcafee.exe', 'mfefire.exe', 'mfeavscan.exe',
            'pccnt.exe', 'tmproxy.exe',
            'egui.exe', 'ekrn.exe',
            'bdagent.exe', 'vsserv.exe',
            'avastui.exe', 'avastsvc.exe',
            'avgui.exe', 'avgsvc.exe',
            'msmpeng.exe', 'nissrv.exe', 'securityhealthservice.exe',
            'spysweeper.exe', 'adaware.exe', 'malwarebytes.exe',
        }
        
        # 系统目录白名单
        self.system_dirs = [
            os.environ.get('WINDIR', 'C:\\Windows'),
            os.environ.get('SystemRoot', 'C:\\Windows'),
            os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'System32'),
            os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'SysWOW64'),
            os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'System32', 'drivers'),
        ]

    def start(self):
        self.running = True
        self.monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.monitor_thread.start()

    def stop(self):
        self.running = False
        if self.monitor_thread:
            self.monitor_thread.join(timeout=2)

    def _monitor_loop(self):
        while self.running:
            try:
                self._check_processes()
            except Exception:
                pass
            time.sleep(self.check_interval)

    def _is_system_process(self, exe_path: str) -> bool:
        """判断进程是否位于系统目录（白名单）"""
        if not exe_path:
            return True
        exe_path_lower = exe_path.lower()
        for sys_dir in self.system_dirs:
            if sys_dir and exe_path_lower.startswith(sys_dir.lower()):
                return True
        return False

    def _is_antivirus_process(self, proc_name: str) -> bool:
        """判断是否为已知杀毒软件进程"""
        if not proc_name:
            return False
        proc_lower = proc_name.lower()
        if proc_lower in self.antivirus_whitelist:
            return True
        if any(proc_lower.startswith(prefix) for prefix in ['av', 'kav', 'mcafee', 'avg']):
            return True
        return False

    def _check_processes(self):
        """检查运行进程（使用psutil或tasklist）"""
        if HAS_PSUTIL:
            try:
                for proc in psutil.process_iter(['name', 'exe']):
                    try:
                        name = proc.info['name']
                        if not name:
                            continue
                        name_lower = name.lower()
                        if self._is_antivirus_process(name):
                            continue
                        if name_lower in self.suspicious_names:
                            exe_path = proc.info['exe']
                            if not self._is_system_process(exe_path):
                                print(f"[Monitor] 发现可疑进程: {name} (路径: {exe_path})")
                                if exe_path and os.path.exists(exe_path):
                                    threat = self.engine.scan_file(exe_path)
                                    if threat:
                                        print(f"[Monitor] 威胁进程确认: {exe_path}")
                    except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                        pass
            except Exception:
                pass
        else:
            try:
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = subprocess.SW_HIDE
                result = subprocess.run(
                    ['tasklist', '/FO', 'CSV', '/NH'], 
                    capture_output=True, text=True, timeout=5,
                    startupinfo=startupinfo,
                    creationflags=subprocess.CREATE_NO_WINDOW
                )
                lines = result.stdout.strip().split('\n')
                for line in lines:
                    if not line:
                        continue
                    parts = line.split('","')
                    if len(parts) >= 1:
                        proc_name = parts[0].strip('"').lower()
                        if self._is_antivirus_process(proc_name):
                            continue
                        if proc_name in self.suspicious_names:
                            print(f"[Monitor] 发现可疑进程: {proc_name}")
            except Exception:
                pass


# ========== 单实例检测（自动关闭旧进程） ==========
def kill_previous_instance():
    """终止当前程序的其他运行实例（同名进程）"""
    current_pid = os.getpid()
    current_exe = sys.executable
    if getattr(sys, 'frozen', False):
        script_name = os.path.basename(sys.executable)
    else:
        script_name = os.path.basename(__file__)
    
    try:
        if HAS_PSUTIL:
            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    if proc.info['pid'] == current_pid:
                        continue
                    if proc.info['name'] and proc.info['name'].lower() in ['python.exe', 'pythonw.exe']:
                        cmdline = proc.info['cmdline']
                        if cmdline and any(script_name in arg for arg in cmdline):
                            proc.terminate()
                            proc.wait(timeout=3)
                    elif getattr(sys, 'frozen', False) and proc.info['name'] == os.path.basename(current_exe):
                        proc.terminate()
                        proc.wait(timeout=3)
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.TimeoutExpired):
                    pass
        else:
            if getattr(sys, 'frozen', False):
                subprocess.run(f'taskkill /F /IM "{os.path.basename(current_exe)}" /FI "PID ne {current_pid}"', 
                               shell=True, capture_output=True)
            else:
                subprocess.run(f'taskkill /F /IM python.exe /FI "PID ne {current_pid}"', 
                               shell=True, capture_output=True)
    except Exception as e:
        print(f"清理旧实例失败: {e}")

def check_single_instance():
    """检查单实例，如果已有实例则关闭旧实例并重新创建互斥体"""
    mutex_name = "Global\\TangAntivirus_2024_SingleInstance"
    kernel32 = ctypes.windll.kernel32
    mutex = kernel32.CreateMutexW(None, False, mutex_name)
    if ctypes.GetLastError() == 183:  # ERROR_ALREADY_EXISTS
        kill_previous_instance()
        time.sleep(0.5)
        mutex = kernel32.CreateMutexW(None, False, mutex_name)
    return mutex


# ========== 托盘图标 ==========
try:
    import win32gui
    import win32con
    import win32api
    HAS_WIN32 = True
except ImportError:
    HAS_WIN32 = False


class TrayIcon:
    def __init__(self, window, show_cb, exit_cb):
        self.window = window
        self.show_cb = show_cb
        self.exit_cb = exit_cb
        self.hwnd = None
        self.nid = None
        if HAS_WIN32:
            try:
                self._create()
            except Exception as e:
                print(f"[Tray] 创建失败: {e}")

    def _create(self):
        wc = win32gui.WNDCLASS()
        wc.lpfnWndProc = self._wnd_proc
        wc.lpszClassName = "TangAV_Tray"
        wc.hInstance = win32api.GetModuleHandle(None)
        atom = win32gui.RegisterClass(wc)
        self.hwnd = win32gui.CreateWindow(atom, "TangAV_Tray", 0, 0, 0, 0, 0, 0, 0, wc.hInstance, None)
        try:
            icon = win32gui.LoadIcon(0, win32con.IDI_SHIELD)
        except:
            icon = win32gui.LoadIcon(0, win32con.IDI_APPLICATION)
        flags = win32gui.NIF_ICON | win32gui.NIF_MESSAGE | win32gui.NIF_TIP
        self.nid = (self.hwnd, 0, flags, win32con.WM_USER + 20, icon, "量盾安全卫士 - 保护中")
        win32gui.Shell_NotifyIcon(win32gui.NIM_ADD, self.nid)

    def _wnd_proc(self, hwnd, msg, wparam, lparam):
        if msg == win32con.WM_USER + 20:
            if lparam == win32con.WM_LBUTTONUP:
                self.show_cb()
            elif lparam == win32con.WM_RBUTTONUP:
                self._show_menu()
        return win32gui.DefWindowProc(hwnd, msg, wparam, lparam)

    def _show_menu(self):
        menu = win32gui.CreatePopupMenu()
        win32gui.AppendMenu(menu, win32con.MF_STRING, 1000, "显示主界面")
        win32gui.AppendMenu(menu, win32con.MF_SEPARATOR, 0, "")
        win32gui.AppendMenu(menu, win32con.MF_STRING, 1001, "退出程序")
        pos = win32gui.GetCursorPos()
        win32gui.SetForegroundWindow(self.hwnd)
        cmd = win32gui.TrackPopupMenu(menu, win32con.TPM_RETURNCMD, pos[0], pos[1], 0, self.hwnd, None)
        if cmd == 1000:
            self.show_cb()
        elif cmd == 1001:
            self.exit_cb()

    def hide(self):
        self.window.withdraw()

    def show(self):
        self.window.deiconify()
        self.window.lift()
        self.window.focus_force()

    def cleanup(self):
        if HAS_WIN32 and self.nid:
            try:
                win32gui.Shell_NotifyIcon(win32gui.NIM_DELETE, self.nid)
            except:
                pass


# ========== 主界面 ==========
class MainWindow:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("量盾安全卫士")
        self.root.geometry("1100x780")
        self.root.minsize(950, 680)

        # 移除窗口左上角默认图标（毛笔标）
        try:
            self.root.iconphoto(False, tk.PhotoImage(width=1, height=1))
        except:
            pass
        self.root.after(50, self._clear_window_icon)

        # 配色
        self.colors = {
            'bg': '#0a0e17',
            'sidebar': '#111827',
            'card': '#1f2937',
            'accent': '#10b981',
            'accent_hover': '#059669',
            'warning': '#f59e0b',
            'danger': '#ef4444',
            'text': '#f9fafb',
            'text_dim': '#9ca3af',
            'border': '#374151',
            'success': '#10b981',
        }
        self.root.configure(bg=self.colors['bg'])

        # 初始化组件
        self.db = VirusDB("virus_db.txt")
        self.engine = ScanEngine(self.db)
        self.monitor = RealtimeMonitor(self.engine)
        self.scanning = False
        self.scan_thread = None
        self.threats_buffer: List[ThreatInfo] = []

        # 加载持久化日志
        self.log_entries = []
        self._load_logs()

        # UI
        self._setup_styles()
        self._create_sidebar()
        self._create_content()

        self.monitor.start()
        self._update_status()

        if HAS_WIN32:
            self.tray = TrayIcon(self.root, self._show_from_tray, self._on_exit)

        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

        self._log("量盾安全卫士已启动 (GPU加速 + 系统白名单增强版)")
        self._log(f"病毒库: {self.db.get_info()['total']} 条")
        self._log("实时监控已开启")

    def _clear_window_icon(self):
        """通过Windows API彻底清除窗口标题栏图标"""
        try:
            hwnd = int(self.root.winfo_id())
            if hwnd:
                WM_SETICON = 0x0080
                ICON_SMALL = 0
                ICON_BIG = 1
                ctypes.windll.user32.SendMessageW(hwnd, WM_SETICON, ICON_SMALL, 0)
                ctypes.windll.user32.SendMessageW(hwnd, WM_SETICON, ICON_BIG, 0)
        except:
            pass

    def _load_logs(self):
        """从磁盘加载历史日志"""
        if os.path.exists(LOG_FILE):
            try:
                with open(LOG_FILE, 'r', encoding='utf-8') as f:
                    self.log_entries = json.load(f)
                for entry in self.log_entries:
                    self._display_log(entry['time'], entry['message'], entry['level'])
            except Exception as e:
                print(f"加载日志失败: {e}")
                self.log_entries = []

    def _save_logs(self):
        """保存日志到磁盘"""
        try:
            with open(LOG_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.log_entries, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"保存日志失败: {e}")

    def _display_log(self, timestamp: str, msg: str, level: str):
        """内部方法：在日志控件中显示一条记录"""
        colors = {"info": self.colors['text'], "success": self.colors['success'],
                  "warning": self.colors['warning'], "error": self.colors['danger']}
        def update():
            self.log_text.config(state=tk.NORMAL)
            self.log_text.insert(tk.END, f"[{timestamp}] ", "time")
            self.log_text.insert(tk.END, f"{msg}\n", level)
            self.log_text.tag_config("time", foreground=self.colors['text_dim'])
            self.log_text.tag_config(level, foreground=colors.get(level, self.colors['text']))
            self.log_text.see(tk.END)
            self.log_text.config(state=tk.DISABLED)
        if threading.current_thread() is threading.main_thread():
            update()
        else:
            self.root.after(0, update)

    def _setup_styles(self):
        style = ttk.Style()
        style.theme_use('default')
        style.configure("Custom.Treeview",
                        background=self.colors['card'],
                        foreground=self.colors['text'],
                        fieldbackground=self.colors['card'],
                        rowheight=30)
        style.configure("Custom.Treeview.Heading",
                        background=self.colors['sidebar'],
                        foreground=self.colors['text'],
                        font=('Microsoft YaHei UI', 10, 'bold'))
        style.map("Custom.Treeview",
                  background=[('selected', self.colors['accent'])])
        style.configure("Custom.Horizontal.TProgressbar",
                        background=self.colors['accent'],
                        troughcolor=self.colors['sidebar'])

    def _create_sidebar(self):
        sidebar = tk.Frame(self.root, bg=self.colors['sidebar'], width=250)
        sidebar.pack(side=tk.LEFT, fill=tk.Y)
        sidebar.pack_propagate(False)

        logo_frame = tk.Frame(sidebar, bg=self.colors['sidebar'])
        logo_frame.pack(fill=tk.X, pady=30)
        tk.Label(logo_frame, text="🛡️", font=("Segoe UI", 48), bg=self.colors['sidebar']).pack()
        tk.Label(logo_frame, text="量盾安全卫士",
                 font=("Microsoft YaHei UI", 22, "bold"),
                 fg=self.colors['accent'], bg=self.colors['sidebar']).pack()
        self.status_label = tk.Label(logo_frame, text="实时保护中",
                                     font=("Microsoft YaHei UI", 11),
                                     fg=self.colors['success'], bg=self.colors['sidebar'])
        self.status_label.pack(pady=(15, 5))
        self.db_label = tk.Label(logo_frame, text="",
                                 font=("Microsoft YaHei UI", 9),
                                 fg=self.colors['text_dim'], bg=self.colors['sidebar'])
        self.db_label.pack()

        nav_items = [
            ("⚡ 快速扫描", self._show_quick),
            ("📁 自定义扫描", self._show_custom),
            ("💾 全盘扫描", self._show_full),
            ("🔒 隔离区", self._show_quarantine),
            ("📋 扫描日志", self._show_logs),
            ("ℹ️ 关于", self._show_about),
        ]
        for text, cmd in nav_items:
            btn = tk.Button(sidebar, text=text,
                            font=("Microsoft YaHei UI", 12),
                            bg=self.colors['sidebar'], fg=self.colors['text_dim'],
                            activebackground=self.colors['sidebar'],
                            activeforeground=self.colors['accent'],
                            bd=0, padx=35, pady=13, anchor=tk.W,
                            cursor="hand2",
                            command=lambda c=cmd: self._select_nav(c))
            btn.pack(fill=tk.X)

        tk.Label(sidebar, text="v5.2plus | tang",
                 font=("Microsoft YaHei UI", 9),
                 fg=self.colors['text_dim'], bg=self.colors['sidebar']).pack(side=tk.BOTTOM, pady=20)

    def _create_content(self):
        self.content = tk.Frame(self.root, bg=self.colors['bg'])
        self.content.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=35, pady=25)
        self.pages = {}
        self._create_quick_page()
        self._create_custom_page()
        self._create_full_page()
        self._create_quarantine_page()
        self._create_logs_page()
        self._create_about_page()
        self._select_nav(self._show_quick)

    def _create_quick_page(self):
        page = tk.Frame(self.content, bg=self.colors['bg'])
        tk.Label(page, text="快速扫描", font=("Microsoft YaHei UI", 32, "bold"),
                 fg=self.colors['text'], bg=self.colors['bg']).pack(anchor=tk.W)
        tk.Label(page, text="扫描系统核心关键目录，极速发现威胁",
                 font=("Microsoft YaHei UI", 12), fg=self.colors['text_dim'],
                 bg=self.colors['bg']).pack(anchor=tk.W, pady=(5, 20))

        # GPU加速选项
        gpu_frame = tk.Frame(page, bg=self.colors['card'], padx=15, pady=10,
                             highlightbackground=self.colors['border'], highlightthickness=1)
        gpu_frame.pack(fill=tk.X, pady=(0, 20))
        self.quick_gpu_var = tk.BooleanVar(value=False)
        gpu_cb = tk.Checkbutton(gpu_frame, text="⚡ 启用GPU加速", variable=self.quick_gpu_var,
                                font=("Microsoft YaHei UI", 11, "bold"),
                                bg=self.colors['card'], fg=self.colors['accent'],
                                selectcolor=self.colors['sidebar'],
                                activebackground=self.colors['card'],
                                activeforeground=self.colors['accent'],
                                highlightthickness=0, bd=0, cursor="hand2")
        gpu_cb.pack(side=tk.LEFT, padx=(5, 15))
        tk.Label(gpu_frame, text="利用GPU并行计算加速扫描，显著提升大文件处理速度",
                 font=("Microsoft YaHei UI", 9), fg=self.colors['text_dim'],
                 bg=self.colors['card']).pack(side=tk.LEFT)

        center = tk.Frame(page, bg=self.colors['bg'])
        center.pack(expand=True)
        self.quick_canvas = tk.Canvas(center, width=220, height=220,
                                      bg=self.colors['bg'], highlightthickness=0)
        self.quick_canvas.pack()
        self.quick_canvas.create_oval(10, 10, 210, 210,
                                      outline=self.colors['accent'], width=3, tags="ring")
        self.quick_btn = self.quick_canvas.create_oval(25, 25, 195, 195,
                                                       fill=self.colors['accent'],
                                                       outline="", tags="btn")
        self.quick_text = self.quick_canvas.create_text(110, 110, text="开始扫描",
                                                        font=("Microsoft YaHei UI", 20, "bold"),
                                                        fill="white")
        self.quick_canvas.tag_bind("btn", "<Button-1>", lambda e: self._start_quick_scan())
        self.quick_canvas.tag_bind("text", "<Button-1>", lambda e: self._start_quick_scan())

        # 进度条
        self.quick_progress_frame = tk.Frame(page, bg=self.colors['bg'])
        self.quick_progress_bar = ttk.Progressbar(self.quick_progress_frame,
                                                  mode='determinate', length=500,
                                                  style="Custom.Horizontal.TProgressbar")
        self.quick_progress_bar.pack()
        self.quick_progress_label = tk.Label(self.quick_progress_frame, text="",
                                             font=("Microsoft YaHei UI", 11),
                                             fg=self.colors['text_dim'], bg=self.colors['bg'])
        self.quick_progress_label.pack(pady=10)
        
        # 停止按钮
        self.quick_stop_btn = tk.Button(self.quick_progress_frame, text="停止扫描",
                                        font=("Microsoft YaHei UI", 10),
                                        bg=self.colors['danger'], fg="white",
                                        bd=0, padx=20, pady=5, cursor="hand2",
                                        command=self._stop_scan)
        self.quick_progress_frame.pack_forget()

        # 结果卡片
        self.quick_result = tk.Frame(page, bg=self.colors['card'],
                                     highlightbackground=self.colors['border'],
                                     highlightthickness=1, padx=40, pady=30)
        self.result_icon = tk.Label(self.quick_result, text="", font=("Segoe UI", 48), bg=self.colors['card'])
        self.result_icon.pack()
        self.result_title = tk.Label(self.quick_result, text="", font=("Microsoft YaHei UI", 20, "bold"),
                                     bg=self.colors['card'])
        self.result_title.pack(pady=10)
        self.result_detail = tk.Label(self.quick_result, text="", font=("Microsoft YaHei UI", 12),
                                      bg=self.colors['card'], wraplength=600)
        self.result_detail.pack()
        self.pages['quick'] = page

    def _create_custom_page(self):
        page = tk.Frame(self.content, bg=self.colors['bg'])
        tk.Label(page, text="自定义扫描", font=("Microsoft YaHei UI", 32, "bold"),
                 fg=self.colors['text'], bg=self.colors['bg']).pack(anchor=tk.W)
        tk.Label(page, text="选择文件或目录进行深度扫描",
                 font=("Microsoft YaHei UI", 12), fg=self.colors['text_dim'],
                 bg=self.colors['bg']).pack(anchor=tk.W, pady=(5, 15))

        # GPU加速选项
        gpu_frame = tk.Frame(page, bg=self.colors['card'], padx=15, pady=10,
                             highlightbackground=self.colors['border'], highlightthickness=1)
        gpu_frame.pack(fill=tk.X, pady=(0, 15))
        self.custom_gpu_var = tk.BooleanVar(value=False)
        gpu_cb = tk.Checkbutton(gpu_frame, text="⚡ 启用GPU加速", variable=self.custom_gpu_var,
                                font=("Microsoft YaHei UI", 11, "bold"),
                                bg=self.colors['card'], fg=self.colors['accent'],
                                selectcolor=self.colors['sidebar'],
                                activebackground=self.colors['card'],
                                activeforeground=self.colors['accent'],
                                highlightthickness=0, bd=0, cursor="hand2")
        gpu_cb.pack(side=tk.LEFT, padx=(5, 15))
        tk.Label(gpu_frame, text="利用GPU并行计算加速扫描，显著提升大文件处理速度",
                 font=("Microsoft YaHei UI", 9), fg=self.colors['text_dim'],
                 bg=self.colors['card']).pack(side=tk.LEFT)

        select_card = tk.Frame(page, bg=self.colors['card'],
                               highlightbackground=self.colors['border'],
                               highlightthickness=1, padx=25, pady=25)
        select_card.pack(fill=tk.X, pady=10)
        self.custom_path = tk.StringVar()
        entry = tk.Entry(select_card, textvariable=self.custom_path,
                         font=("Microsoft YaHei UI", 12),
                         bg=self.colors['bg'], fg=self.colors['text'],
                         insertbackground=self.colors['text'],
                         relief=tk.FLAT, width=50)
        entry.pack(side=tk.LEFT, padx=(0, 15), ipady=12)
        tk.Button(select_card, text="浏览目录", font=("Microsoft YaHei UI", 11),
                  bg=self.colors['sidebar'], fg=self.colors['text'],
                  activebackground=self.colors['accent'],
                  bd=0, padx=25, pady=12, cursor="hand2",
                  command=self._browse_dir).pack(side=tk.LEFT, padx=5)
        tk.Button(select_card, text="浏览文件", font=("Microsoft YaHei UI", 11),
                  bg=self.colors['sidebar'], fg=self.colors['text'],
                  activebackground=self.colors['accent'],
                  bd=0, padx=25, pady=12, cursor="hand2",
                  command=self._browse_file).pack(side=tk.LEFT, padx=5)

        self.custom_scan_btn = tk.Button(page, text="开始扫描",
                                         font=("Microsoft YaHei UI", 14, "bold"),
                                         bg=self.colors['accent'], fg="white",
                                         activebackground=self.colors['accent_hover'],
                                         bd=0, padx=60, pady=16, cursor="hand2",
                                         command=self._start_custom_scan)
        self.custom_scan_btn.pack(pady=25)

        self.custom_progress_frame = tk.Frame(page, bg=self.colors['bg'])
        self.custom_progress_bar = ttk.Progressbar(self.custom_progress_frame,
                                                   mode='determinate', length=500,
                                                   style="Custom.Horizontal.TProgressbar")
        self.custom_progress_bar.pack()
        self.custom_progress_label = tk.Label(self.custom_progress_frame, text="",
                                              font=("Microsoft YaHei UI", 11),
                                              fg=self.colors['text_dim'], bg=self.colors['bg'])
        self.custom_progress_label.pack(pady=10)
        self.custom_stop_btn = tk.Button(self.custom_progress_frame, text="停止扫描",
                                         font=("Microsoft YaHei UI", 10),
                                         bg=self.colors['danger'], fg="white",
                                         bd=0, padx=20, pady=5, cursor="hand2",
                                         command=self._stop_scan)
        self.custom_progress_frame.pack_forget()

        columns = ('path', 'type', 'level', 'source')
        self.custom_tree = ttk.Treeview(page, columns=columns, show='headings',
                                        height=10, style="Custom.Treeview")
        self.custom_tree.heading('path', text='文件路径')
        self.custom_tree.heading('type', text='威胁类型')
        self.custom_tree.heading('level', text='危险等级')
        self.custom_tree.heading('source', text='检测来源')
        self.custom_tree.column('path', width=380)
        self.custom_tree.column('type', width=160)
        self.custom_tree.column('level', width=80)
        self.custom_tree.column('source', width=100)
        scrollbar = ttk.Scrollbar(page, orient=tk.VERTICAL, command=self.custom_tree.yview)
        self.custom_tree.configure(yscrollcommand=scrollbar.set)
        self.custom_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.context_menu = tk.Menu(self.root, tearoff=0,
                                    bg=self.colors['card'], fg=self.colors['text'])
        self.context_menu.add_command(label="🔒 隔离文件", command=self._quarantine_selected)
        self.context_menu.add_command(label="🗑️ 直接删除", command=self._delete_selected)
        self.custom_tree.bind("<Button-3>", self._show_context_menu)
        self.pages['custom'] = page

    def _create_full_page(self):
        page = tk.Frame(self.content, bg=self.colors['bg'])
        tk.Label(page, text="全盘扫描", font=("Microsoft YaHei UI", 32, "bold"),
                 fg=self.colors['text'], bg=self.colors['bg']).pack(anchor=tk.W)
        tk.Label(page, text="全面扫描所有磁盘，可能需要较长时间",
                 font=("Microsoft YaHei UI", 12), fg=self.colors['text_dim'],
                 bg=self.colors['bg']).pack(anchor=tk.W, pady=(5, 15))

        # GPU加速选项
        gpu_frame = tk.Frame(page, bg=self.colors['card'], padx=15, pady=10,
                             highlightbackground=self.colors['border'], highlightthickness=1)
        gpu_frame.pack(fill=tk.X, pady=(0, 10))

        gpu_row_top = tk.Frame(gpu_frame, bg=self.colors['card'])
        gpu_row_top.pack(fill=tk.X)
        self.full_gpu_var = tk.BooleanVar(value=False)
        gpu_cb = tk.Checkbutton(gpu_row_top, text="⚡ 启用GPU加速", variable=self.full_gpu_var,
                                font=("Microsoft YaHei UI", 11, "bold"),
                                bg=self.colors['card'], fg=self.colors['accent'],
                                selectcolor=self.colors['sidebar'],
                                activebackground=self.colors['card'],
                                activeforeground=self.colors['accent'],
                                highlightthickness=0, bd=0, cursor="hand2")
        gpu_cb.pack(side=tk.LEFT, padx=(5, 15))
        tk.Label(gpu_row_top, text="利用GPU并行计算加速扫描，全盘扫描时推荐开启",
                 font=("Microsoft YaHei UI", 9), fg=self.colors['text_dim'],
                 bg=self.colors['card']).pack(side=tk.LEFT)

        warn_card = tk.Frame(page, bg=self.colors['warning'], padx=20, pady=15)
        warn_card.pack(fill=tk.X, pady=10)
        tk.Label(warn_card, text="⚠️ 全盘扫描会遍历所有磁盘（系统目录已自动跳过），请耐心等待",
                 font=("Microsoft YaHei UI", 11), fg=self.colors['bg'],
                 bg=self.colors['warning']).pack()

        self.full_scan_btn = tk.Button(page, text="开始全盘扫描",
                                       font=("Microsoft YaHei UI", 14, "bold"),
                                       bg=self.colors['accent'], fg="white",
                                       activebackground=self.colors['accent_hover'],
                                       bd=0, padx=60, pady=16, cursor="hand2",
                                       command=self._start_full_scan)
        self.full_scan_btn.pack(pady=25)

        self.full_progress_frame = tk.Frame(page, bg=self.colors['bg'])
        self.full_progress_bar = ttk.Progressbar(self.full_progress_frame,
                                                 mode='determinate', length=500,
                                                 style="Custom.Horizontal.TProgressbar")
        self.full_progress_bar.pack()
        self.full_progress_label = tk.Label(self.full_progress_frame, text="",
                                            font=("Microsoft YaHei UI", 11),
                                            fg=self.colors['text_dim'], bg=self.colors['bg'])
        self.full_progress_label.pack(pady=10)
        self.full_stop_btn = tk.Button(self.full_progress_frame, text="停止扫描",
                                       font=("Microsoft YaHei UI", 10),
                                       bg=self.colors['danger'], fg="white",
                                       bd=0, padx=20, pady=5, cursor="hand2",
                                       command=self._stop_scan)
        self.full_progress_frame.pack_forget()

        frame = tk.Frame(page, bg=self.colors['bg'])
        frame.pack(fill=tk.BOTH, expand=True, pady=10)
        columns = ('path', 'type', 'level', 'source')
        self.full_tree = ttk.Treeview(frame, columns=columns, show='headings',
                                      height=12, style="Custom.Treeview")
        self.full_tree.heading('path', text='文件路径')
        self.full_tree.heading('type', text='威胁类型')
        self.full_tree.heading('level', text='危险等级')
        self.full_tree.heading('source', text='检测来源')
        self.full_tree.column('path', width=500)
        self.full_tree.column('type', width=200)
        self.full_tree.column('level', width=80)
        self.full_tree.column('source', width=100)
        scrollbar = ttk.Scrollbar(frame, orient=tk.VERTICAL, command=self.full_tree.yview)
        self.full_tree.configure(yscrollcommand=scrollbar.set)
        self.full_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.pages['full'] = page

    def _create_quarantine_page(self):
        page = tk.Frame(self.content, bg=self.colors['bg'])
        tk.Label(page, text="隔离区", font=("Microsoft YaHei UI", 32, "bold"),
                 fg=self.colors['text'], bg=self.colors['bg']).pack(anchor=tk.W)
        tk.Label(page, text="已隔离的危险文件，可恢复或永久删除",
                 font=("Microsoft YaHei UI", 12), fg=self.colors['text_dim'],
                 bg=self.colors['bg']).pack(anchor=tk.W, pady=(5, 25))

        toolbar = tk.Frame(page, bg=self.colors['bg'])
        toolbar.pack(fill=tk.X, pady=10)
        tk.Button(toolbar, text="🔄 刷新", font=("Microsoft YaHei UI", 11),
                  bg=self.colors['card'], fg=self.colors['text'],
                  bd=0, padx=25, pady=10, cursor="hand2",
                  command=self._refresh_quarantine).pack(side=tk.LEFT, padx=5)
        tk.Button(toolbar, text="✅ 恢复选中", font=("Microsoft YaHei UI", 11),
                  bg=self.colors['success'], fg="white",
                  bd=0, padx=25, pady=10, cursor="hand2",
                  command=self._restore_selected).pack(side=tk.LEFT, padx=5)
        tk.Button(toolbar, text="🗑️ 永久删除", font=("Microsoft YaHei UI", 11),
                  bg=self.colors['danger'], fg="white",
                  bd=0, padx=25, pady=10, cursor="hand2",
                  command=self._delete_quarantine_selected).pack(side=tk.LEFT, padx=5)

        columns = ('original', 'type', 'time')
        self.quar_tree = ttk.Treeview(page, columns=columns, show='headings',
                                      height=15, style="Custom.Treeview")
        self.quar_tree.heading('original', text='原路径')
        self.quar_tree.heading('type', text='威胁类型')
        self.quar_tree.heading('time', text='隔离时间')
        self.quar_tree.column('original', width=500)
        self.quar_tree.column('type', width=250)
        self.quar_tree.column('time', width=180)
        scrollbar = ttk.Scrollbar(page, orient=tk.VERTICAL, command=self.quar_tree.yview)
        self.quar_tree.configure(yscrollcommand=scrollbar.set)
        self.quar_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.pages['quarantine'] = page

    def _create_logs_page(self):
        page = tk.Frame(self.content, bg=self.colors['bg'])
        tk.Label(page, text="扫描日志", font=("Microsoft YaHei UI", 32, "bold"),
                 fg=self.colors['text'], bg=self.colors['bg']).pack(anchor=tk.W)
        self.log_text = scrolledtext.ScrolledText(page,
                                                 font=("Consolas", 11),
                                                 bg=self.colors['card'],
                                                 fg=self.colors['text'],
                                                 insertbackground=self.colors['text'],
                                                 relief=tk.FLAT, padx=15, pady=15)
        self.log_text.pack(fill=tk.BOTH, expand=True, pady=20)
        self.log_text.config(state=tk.DISABLED)
        tk.Button(page, text="清空日志", font=("Microsoft YaHei UI", 11),
                  bg=self.colors['card'], fg=self.colors['text'],
                  bd=0, padx=25, pady=10, cursor="hand2",
                  command=self._clear_logs).pack(anchor=tk.E)
        self.pages['logs'] = page

    def _create_about_page(self):
        page = tk.Frame(self.content, bg=self.colors['bg'])
        tk.Label(page, text="关于", font=("Microsoft YaHei UI", 32, "bold"),
                 fg=self.colors['text'], bg=self.colors['bg']).pack(anchor=tk.W)

        about_card = tk.Frame(page, bg=self.colors['card'],
                              highlightbackground=self.colors['border'],
                              highlightthickness=1, padx=40, pady=40)
        about_card.pack(pady=30)
        tk.Label(about_card, text="🛡️", font=("Segoe UI", 64), bg=self.colors['card']).pack()
        tk.Label(about_card, text="量盾安全卫士",
                 font=("Microsoft YaHei UI", 28, "bold"),
                 fg=self.colors['accent'], bg=self.colors['card']).pack(pady=15)
        tk.Label(about_card, text="版本: v5.2plus", font=("Microsoft YaHei UI", 14),
                 fg=self.colors['text'], bg=self.colors['card']).pack()
        tk.Label(about_card, text="开发者: tang", font=("Microsoft YaHei UI", 12),
                 fg=self.colors['text_dim'], bg=self.colors['card']).pack(pady=10)

        contact_card = tk.Frame(about_card, bg=self.colors['sidebar'], padx=30, pady=20)
        contact_card.pack(pady=20)
        tk.Label(contact_card, text="📧 问题反馈邮箱:", font=("Microsoft YaHei UI", 12),
                 fg=self.colors['text'], bg=self.colors['sidebar']).pack()
        email_label = tk.Label(contact_card, text="QQ201324qq0596@outlook.com",
                               font=("Microsoft YaHei UI", 14, "bold"),
                               fg=self.colors['accent'], bg=self.colors['sidebar'], cursor="hand2")
        email_label.pack()
        email_label.bind("<Button-1>", lambda e: self._copy_email())
        tk.Label(contact_card, text="（点击复制邮箱地址）", font=("Microsoft YaHei UI", 9),
                 fg=self.colors['text_dim'], bg=self.colors['sidebar']).pack()

        features = tk.Frame(about_card, bg=self.colors['sidebar'], padx=30, pady=20)
        features.pack(pady=20)
        tk.Label(features, text="✨ 功能特点", font=("Microsoft YaHei UI", 14, "bold"),
                 fg=self.colors['text'], bg=self.colors['sidebar']).pack()
        feature_list = [
            "• 快速扫描 - 扫描系统核心关键目录（极速）",
            "• 自定义扫描 - 扫描指定文件或目录",
            "• 全盘扫描 - 全面扫描所有磁盘",
            "• GPU加速扫描 - 并行计算大幅提升速度",
            "• 实时监控 - 持续保护系统安全",
            "• 隔离沙盒 - 安全隔离危险文件",
            "• MD5检测 + 启发式分析（极低误报）",
            "• 多线程扫描 - 速度提升3-5倍",
            "• 白名单缓存 - 避免重复扫描",
            "• 系统文件白名单增强 - 彻底杜绝误报",
        ]
        for feat in feature_list:
            tk.Label(features, text=feat, font=("Microsoft YaHei UI", 10),
                     fg=self.colors['text_dim'], bg=self.colors['sidebar']).pack(anchor=tk.W, pady=2)
        self.pages['about'] = page

    def _copy_email(self):
        self.root.clipboard_clear()
        self.root.clipboard_append("QQ201324qq0596@outlook.com")
        self._log("邮箱地址已复制到剪贴板")
        messagebox.showinfo("提示", "邮箱地址已复制到剪贴板")

    def _select_nav(self, show_func):
        for page in self.pages.values():
            page.pack_forget()
        show_func()

    def _show_quick(self): self.pages['quick'].pack(fill=tk.BOTH, expand=True)
    def _show_custom(self): self.pages['custom'].pack(fill=tk.BOTH, expand=True)
    def _show_full(self): self.pages['full'].pack(fill=tk.BOTH, expand=True)
    def _show_quarantine(self): self.pages['quarantine'].pack(fill=tk.BOTH, expand=True); self._refresh_quarantine()
    def _show_logs(self): self.pages['logs'].pack(fill=tk.BOTH, expand=True)
    def _show_about(self): self.pages['about'].pack(fill=tk.BOTH, expand=True)

    def _update_status(self):
        info = self.db.get_info()
        self.db_label.config(text=f"病毒库: {info['total']} 条")

    def _browse_dir(self):
        path = filedialog.askdirectory()
        if path:
            self.custom_path.set(path)

    def _browse_file(self):
        path = filedialog.askopenfilename()
        if path:
            self.custom_path.set(path)

    def _stop_scan(self):
        if self.scanning:
            self.engine.stop()
            self._log("用户停止了扫描")

    def _start_quick_scan(self):
        if self.scanning:
            return
        self.scanning = True
        self.engine.reset()
        # 设置GPU加速
        self.engine.gpu_accel = self.quick_gpu_var.get()
        gpu_tag = " [GPU加速]" if self.engine.gpu_accel else ""
        self.threats_buffer.clear()
        self.quick_progress_bar['value'] = 0
        self.quick_progress_label.config(text=f"正在扫描{gpu_tag}...")
        self.quick_progress_frame.pack(pady=20)
        self.quick_stop_btn.pack(pady=5)
        self.quick_result.pack_forget()
        self.quick_canvas.itemconfig(self.quick_btn, fill=self.colors['text_dim'])
        self.quick_canvas.itemconfig(self.quick_text, text="扫描中...")

        def scan_thread():
            try:
                gpu = self.engine.gpu_accel
                def on_progress(current, total):
                    percent = int(current / total * 100) if total > 0 else 0
                    tag = " [GPU加速]" if gpu else ""
                    self.root.after(0, lambda: self.quick_progress_bar.config(value=percent))
                    self.root.after(0, lambda: self.quick_progress_label.config(
                        text=f"已扫描 {current} / {total} 文件 ({percent}%){tag}"))
                def on_threat(t):
                    self.threats_buffer.append(t)
                    self._log(f"发现威胁: {os.path.basename(t.path)} - {t.threat_type}", "warning")
                threats = self.engine.quick_scan(on_threat=on_threat, on_progress=on_progress)
                self.root.after(0, lambda: self._finish_quick_scan(len(threats)))
            except Exception as e:
                self.root.after(0, lambda: self._log(f"快速扫描失败: {e}", "error"))
                self.root.after(0, self._reset_quick_ui)
        self._log(f"开始快速扫描{gpu_tag}...")
        threading.Thread(target=scan_thread, daemon=True).start()

    def _finish_quick_scan(self, count):
        self._reset_quick_ui()
        if count > 0:
            self.result_icon.config(text="⚠️", fg=self.colors['danger'])
            self.result_title.config(text=f"发现 {count} 个威胁", fg=self.colors['danger'])
            detail = "\n".join([f"• {os.path.basename(t.path)} [{t.threat_type}]" for t in self.threats_buffer[:5]])
            if len(self.threats_buffer) > 5:
                detail += f"\n... 还有 {len(self.threats_buffer) - 5} 个"
            self.result_detail.config(text=detail, fg=self.colors['text'])
            self._log(f"快速扫描完成: 发现 {count} 个威胁", "warning")
        else:
            self.result_icon.config(text="✅", fg=self.colors['success'])
            self.result_title.config(text="系统安全", fg=self.colors['success'])
            self.result_detail.config(text="未发现威胁文件", fg=self.colors['text_dim'])
            self._log("快速扫描完成: 系统安全", "success")
        self.quick_result.pack(fill=tk.X, pady=20)

    def _reset_quick_ui(self):
        self.scanning = False
        self.quick_progress_frame.pack_forget()
        self.quick_canvas.itemconfig(self.quick_btn, fill=self.colors['accent'])
        self.quick_canvas.itemconfig(self.quick_text, text="开始扫描")

    def _start_custom_scan(self):
        if self.scanning:
            return
        path = self.custom_path.get()
        if not path or not os.path.exists(path):
            messagebox.showwarning("提示", "请选择有效的文件或目录")
            return
        for item in self.custom_tree.get_children():
            self.custom_tree.delete(item)
        self.scanning = True
        self.engine.reset()
        # 设置GPU加速
        self.engine.gpu_accel = self.custom_gpu_var.get()
        gpu_tag = " [GPU加速]" if self.engine.gpu_accel else ""
        self.custom_scan_btn.config(state=tk.DISABLED, text="准备中...")
        self.custom_progress_bar['value'] = 0
        self.custom_progress_label.config(text=f"正在扫描{gpu_tag}...")
        self.custom_progress_frame.pack(pady=20)
        self.custom_stop_btn.pack(pady=5)

        def scan_thread():
            try:
                gpu = self.engine.gpu_accel
                def on_progress(current, total):
                    percent = int(current / total * 100) if total > 0 else 0
                    tag = " [GPU加速]" if gpu else ""
                    self.root.after(0, lambda: self.custom_progress_bar.config(value=percent))
                    self.root.after(0, lambda: self.custom_progress_label.config(
                        text=f"已扫描 {current} / {total} 文件 ({percent}%){tag}"))
                def on_threat(t):
                    self.root.after(0, lambda: self._add_to_tree(self.custom_tree, t))
                    self._log(f"发现威胁: {os.path.basename(t.path)} - {t.threat_type}", "warning")
                threats = self.engine.scan_path_multithread(path, recursive=os.path.isdir(path),
                                                            on_threat=on_threat, on_progress=on_progress)
                self.root.after(0, lambda: self._finish_custom_scan(len(threats)))
            except Exception as e:
                self.root.after(0, lambda: self._log(f"自定义扫描失败: {e}", "error"))
                self.root.after(0, self._reset_custom_ui)
        self._log(f"开始自定义扫描: {path}{gpu_tag}")
        threading.Thread(target=scan_thread, daemon=True).start()

    def _finish_custom_scan(self, count):
        self._reset_custom_ui()
        if count == 0:
            self._log("自定义扫描完成: 未发现威胁")
            messagebox.showinfo("扫描完成", "未发现威胁文件")
        else:
            self._log(f"自定义扫描完成: 发现 {count} 个威胁", "warning")
            messagebox.showwarning("扫描完成", f"发现 {count} 个威胁文件，建议隔离")

    def _reset_custom_ui(self):
        self.scanning = False
        self.custom_scan_btn.config(state=tk.NORMAL, text="开始扫描")
        self.custom_progress_frame.pack_forget()

    def _start_full_scan(self):
        if self.scanning:
            return
        for item in self.full_tree.get_children():
            self.full_tree.delete(item)
        self.scanning = True
        self.engine.reset()
        # 设置GPU加速
        self.engine.gpu_accel = self.full_gpu_var.get()
        gpu_tag = " [GPU加速]" if self.engine.gpu_accel else ""
        self.full_scan_btn.config(state=tk.DISABLED, text="准备中...")
        self.full_progress_bar['value'] = 0
        self.full_progress_label.config(text=f"正在扫描所有磁盘{gpu_tag}...")
        self.full_progress_frame.pack(pady=20)
        self.full_stop_btn.pack(pady=5)

        def scan_thread():
            try:
                gpu = self.engine.gpu_accel
                def on_progress(current, total):
                    percent = int(current / total * 100) if total > 0 else 0
                    tag = " [GPU加速]" if gpu else ""
                    self.root.after(0, lambda: self.full_progress_bar.config(value=percent))
                    self.root.after(0, lambda: self.full_progress_label.config(
                        text=f"已扫描 {current} / {total} 文件 ({percent}%){tag}"))
                def on_threat(t):
                    self.root.after(0, lambda: self._add_to_tree(self.full_tree, t))
                    self._log(f"发现威胁: {os.path.basename(t.path)} - {t.threat_type}", "warning")
                threats = self.engine.full_scan(on_threat=on_threat, on_progress=on_progress)
                self.root.after(0, lambda: self._finish_full_scan(len(threats)))
            except Exception as e:
                self.root.after(0, lambda: self._log(f"全盘扫描失败: {e}", "error"))
                self.root.after(0, self._reset_full_ui)
        self._log(f"开始全盘扫描{gpu_tag}...")
        threading.Thread(target=scan_thread, daemon=True).start()

    def _finish_full_scan(self, count):
        self._reset_full_ui()
        if count > 0:
            self._log(f"全盘扫描完成: 发现 {count} 个威胁", "warning")
            messagebox.showwarning("扫描完成", f"发现 {count} 个威胁文件，请检查隔离区")
        else:
            self._log("全盘扫描完成: 未发现威胁")
            messagebox.showinfo("扫描完成", "您的系统安全！")

    def _reset_full_ui(self):
        self.scanning = False
        self.full_scan_btn.config(state=tk.NORMAL, text="开始全盘扫描")
        self.full_progress_frame.pack_forget()

    def _add_to_tree(self, tree, threat: ThreatInfo):
        tree.insert('', tk.END, values=(
            threat.path,
            threat.threat_type,
            f"{threat.severity}/10",
            threat.source
        ))
        tree.see(tk.END)

    def _show_context_menu(self, event):
        item = self.custom_tree.identify_row(event.y)
        if item:
            self.custom_tree.selection_set(item)
            self.context_menu.post(event.x_root, event.y_root)

    def _quarantine_selected(self):
        selected = self.custom_tree.selection()
        if not selected:
            return
        values = self.custom_tree.item(selected[0])['values']
        if len(values) < 1:
            return
        path = values[0]
        if messagebox.askyesno("确认", f"确定要隔离以下文件吗？\n{path}"):
            threat = ThreatInfo(path=path, md5="unknown", threat_type="未知", severity=5, source="manual")
            if self.engine.quarantine_file(threat):
                self._log(f"已隔离: {os.path.basename(path)}", "success")
                self.custom_tree.delete(selected[0])
                messagebox.showinfo("成功", "文件已隔离")
            else:
                messagebox.showerror("错误", "隔离失败")

    def _delete_selected(self):
        selected = self.custom_tree.selection()
        if not selected:
            return
        values = self.custom_tree.item(selected[0])['values']
        if len(values) < 1:
            return
        path = values[0]
        if messagebox.askyesno("警告", f"永久删除以下文件？\n{path}\n\n此操作不可恢复！", icon='warning'):
            try:
                os.remove(path)
                self._log(f"已删除: {os.path.basename(path)}", "success")
                self.custom_tree.delete(selected[0])
            except Exception as e:
                messagebox.showerror("错误", f"删除失败: {e}")

    def _refresh_quarantine(self):
        for item in self.quar_tree.get_children():
            self.quar_tree.delete(item)
        files = self.engine.get_quarantine_list()
        for info in files:
            self.quar_tree.insert('', tk.END, values=(
                info.get('original_path', '未知'),
                info.get('threat_type', '未知'),
                info.get('quarantine_time', '未知')
            ))
        self._log(f"隔离区已刷新: {len(files)} 个文件")

    def _restore_selected(self):
        selected = self.quar_tree.selection()
        if not selected:
            messagebox.showwarning("提示", "请先选择要恢复的文件")
            return
        item = self.quar_tree.item(selected[0])
        original = item['values'][0]
        if messagebox.askyesno("确认", f"恢复文件到:\n{original}"):
            files = self.engine.get_quarantine_list()
            idx = self.quar_tree.index(selected[0])
            if idx < len(files):
                info = files[idx]
                safe_name = info.get('quarantine_filename')
                if safe_name and self.engine.restore_quarantined(safe_name):
                    self._log(f"已恢复: {os.path.basename(original)}", "success")
                    self.quar_tree.delete(selected[0])
                    messagebox.showinfo("成功", "文件已恢复")
                else:
                    messagebox.showerror("错误", "恢复失败")

    def _delete_quarantine_selected(self):
        selected = self.quar_tree.selection()
        if not selected:
            messagebox.showwarning("提示", "请先选择要删除的文件")
            return
        if messagebox.askyesno("警告", "永久删除选中文件？\n\n此操作不可恢复！", icon='warning'):
            files = self.engine.get_quarantine_list()
            idx = self.quar_tree.index(selected[0])
            if idx < len(files):
                info = files[idx]
                safe_name = info.get('quarantine_filename')
                if safe_name and self.engine.delete_quarantined(safe_name):
                    self._log(f"已删除隔离文件", "success")
                    self.quar_tree.delete(selected[0])

    def _clear_logs(self):
        """清空所有日志（界面及文件）"""
        self.log_text.config(state=tk.NORMAL)
        self.log_text.delete(1.0, tk.END)
        self.log_text.config(state=tk.DISABLED)
        self.log_entries.clear()
        self._save_logs()
        self._log("日志已清空", "info")

    def _log(self, msg: str, level: str = "info"):
        timestamp = datetime.now().strftime("%H:%M:%S")
        full_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.log_entries.append({
            "time": full_timestamp,
            "level": level,
            "message": msg
        })
        self._save_logs()
        self._display_log(timestamp, msg, level)

    def _on_close(self):
        if HAS_WIN32:
            self.tray.hide()
        else:
            self._on_exit()

    def _show_from_tray(self):
        self.tray.show()

    def _on_exit(self):
        self._log("正在关闭...")
        self.monitor.stop()
        self.engine.whitelist.save()
        if HAS_WIN32:
            self.tray.cleanup()
        self.root.destroy()
        sys.exit(0)


# ========== 程序入口 ==========
if __name__ == "__main__":
    mutex = check_single_instance()
    if mutex is None:
        pass
    root = tk.Tk()
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except:
            pass
    app = MainWindow(root)
    root.mainloop()
