/*
    This Yara ruleset is under the GNU-GPLv2 license (http://www.gnu.org/licenses/gpl-2.0.html) and open to any user or organization, as    long as you use it under this license.

*/

rule custom_ssh_backdoor_server
{

    meta:
        description = "Custome SSH backdoor based on python and paramiko - file server.py"
        author = "Florian Roth"
        reference = "https://goo.gl/S46L3o"
        date = "2015-05-14"
        hash = "0953b6c2181249b94282ca5736471f85d80d41c9"

    strings:
        $s0 = "command= raw_input(\"Enter command: \").strip('n')" fullword ascii
        $s1 = "print '[-] (Failed to load moduli -- gex will be unsupported.)'" fullword ascii
        $s2 = "print '[-] Listen/bind/accept failed: ' + str(e)" fullword ascii
        $s3 = "chan.send(command)" fullword ascii
        $s4 = "print '[-] SSH negotiation failed.'" fullword ascii
        $s5 = "except paramiko.SSHException, x:" fullword ascii

    condition:
        filesize < 10KB and 5 of them
}
